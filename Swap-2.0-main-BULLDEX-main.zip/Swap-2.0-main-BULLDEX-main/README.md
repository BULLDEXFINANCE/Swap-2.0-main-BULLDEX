# swap-2.0-
Main contracts for BULLDEX

### Swap 2.0
Swap 2.0 Base Contract to be used on BULLDEX

## Get Started
- Clone Repo
- In terminal of your choice:
  - cd [Repo_Location]
  - yarn
- Add and Remove Fees and Fee Addresses as needed in: 
  - struct Fees
  - struct FeeValues
  - constructor
  - function depositLPFee
- Deploy with Router, Fee Values, and Fee Addresses in Constructor

## PUPSWAP Routers
Mainnet: Coming soon   
Testnet: Coming Soon

## Testing Environment
Soon you can test your contract using testnet at https://testnet.bulldex.finance

